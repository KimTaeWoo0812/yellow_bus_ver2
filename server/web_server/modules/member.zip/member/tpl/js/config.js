function enableSignUpTab(isEnable)
{
	var $ = jQuery;
	$('#signupTab').toggle(isEnable);
}
